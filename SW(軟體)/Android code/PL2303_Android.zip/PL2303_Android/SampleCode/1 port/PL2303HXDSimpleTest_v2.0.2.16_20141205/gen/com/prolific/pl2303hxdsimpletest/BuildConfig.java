/** Automatically generated file. DO NOT MODIFY */
package com.prolific.pl2303hxdsimpletest;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}